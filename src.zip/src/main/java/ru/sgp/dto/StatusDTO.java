package ru.sgp.dto;

import lombok.Data;

@Data
public class StatusDTO {
    private Long id;
    private String name;
}
