package ru.sgp.dto;

import lombok.Data;

@Data
public class EventTypeDTO {
    private Long id;
    private String name;
}
