package ru.sgp.dto.report;

import lombok.Data;

@Data
public class MVZReportShortDTO {
    private String hotel;
    private String mvz;
    private String mvzName;
    private Integer days;
}
