package ru.sgp.dto;

import lombok.Data;

@Data
public class ExtraDTO {
    private Long id;
    private String name;
    private String description;
    private Float cost;
}
