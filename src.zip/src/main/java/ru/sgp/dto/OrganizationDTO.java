package ru.sgp.dto;

import lombok.Data;

@Data
public class OrganizationDTO {
    private Long id;
    private String name;
}
