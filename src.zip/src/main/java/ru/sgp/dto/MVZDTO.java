package ru.sgp.dto;

import lombok.Data;

@Data
public class MVZDTO {
    private String employeeTab;
    private String employeeFio;
    private String mvz;
    private String mvzName;
    private String filial;
    private String organization;
}
